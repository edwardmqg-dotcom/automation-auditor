import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';import{fileURLToPath}from'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)),read=p=>JSON.parse(fs.readFileSync(path.join(root,p)));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');const inventory=read('input-inventory.json');
assert.equal(inventory.records.length,12);
for(const item of inventory.records){const b=fs.readFileSync(path.join(root,'01_Input_images',item.name));assert.equal(sha(b),item.sha256,item.name);assert.equal(b.length,item.size_bytes);assert.equal(b.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(b.readUInt32BE(16),item.width);assert.equal(b.readUInt32BE(20),item.height);}
const manifest=read('Optional_task_package/image-task.manifest.json');assert.equal(manifest.input_files.length,13);
for(const file of manifest.input_files){assert(!file.path.includes('/')&&!file.path.includes('\\'));const b=fs.readFileSync(path.join(root,'Optional_task_package',file.path));assert.equal(sha(b),file.sha256);assert.equal(b.length,file.size_bytes);}
const o=read('observation.json');
function total(items){let end=-Infinity;return items.reduce((sum,item)=>{const start=Date.parse(item.started_at),stop=Date.parse(item.ended_at);assert(Number.isFinite(start)&&Number.isFinite(stop)&&start>=end&&stop>=start);assert.equal(stop-start,item.duration_ms);end=stop;return sum+item.duration_ms;},0);}
const human=total(o.human_active_segments),automation=total(o.automation_active_segments),saved=human-automation,percent=saved/human*100;
assert.equal(human,o.expected.human_ms);assert.equal(automation,o.expected.automation_ms);assert.equal(saved,o.expected.difference_ms);assert.equal(percent.toFixed(1),o.expected.display_percent);
console.log(JSON.stringify({input_pngs_verified:12,optional_package_inputs_verified:13,human_ms:human,automation_ms:automation,saved_ms:saved,percent,scope:'File integrity and excerpt arithmetic only. This is not a full original-record validation, new experiment, independent completion check or guarantee of rerun times.'},null,2));
