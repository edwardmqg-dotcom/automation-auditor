# Automation Auditor image replay kit

Use this kit to try a complete time comparison with a separate automation tool. It contains 12 synthetic calibration PNGs, not customer photos. No account or API key is included.

## Choose your route

- **Review the existing observation:** run `node verify-inputs.mjs` with Node.js 22.13 or later. It checks image fingerprints, dimensions and the arithmetic excerpt: 755,930ms manual work, 569,850ms with automation, 186,080ms less, displayed as 24.6%. This excerpt is not an importable run bundle. Full-record validation is a separate private reviewer kit.
- **Measure your own work:** follow [the complete walkthrough](WALKTHROUGH.en.md). Your times and savings may differ. Use your own reviewer reference; do not sign as EddieM or overwrite a saved run.

Start at [Automation Auditor](https://automation-auditor-reviewer.edwardmqg.workers.dev/). [Bulk Resize Photos](https://bulkresizephotos.com/en) is the external tool. Its current homepage states that it is free and requires no signup. It is operated by a third party; a dated observation is not a promise of permanent availability or an immutable release.

## Contents

| Folder or file | Purpose |
| --- | --- |
| `01_Input_images` | The 12 fixed original PNGs; use these for the automation-assisted run |
| `02_Shared_task` | Task name and the same three completion questions in English |
| `03_Human_working_copies` | Fresh copies for manual editing; never use old processed images |
| `04_Human_result` | Initially empty; save your own manual JPEGs here |
| `05_Version_A_result` | Initially empty; save your own automated JPEGs here |
| `Optional_task_package` | An optional ready-made task package: select all 14 files in this folder together |
| `input-inventory.json` | Image dimensions, target dimensions and SHA-256 hashes |
| `observation.json` | Clearly labelled arithmetic excerpt of the prior observation, with original-record hashes |

The default walkthrough imports only the 12 PNGs and uses the three-question form. You do not need a JSON file. The optional package preserves the historical task's input and instruction fingerprints and review date; its manifest is newly reconstructed, not a recovered original export. It contains no run events or completion decisions. Do not combine the two import routes or select the entire kit folder.

The previous observation used Mac Preview one image at a time, followed by Bulk Resize Photos in two batches. Preview also supports batching: this is not a claim to beat the fastest manual method. One operator, repeated materials, fixed order and prior instruction limit generalization. The result is task-specific, not independent quality certification or a company-wide ROI forecast.

Only the optional AI explanation feature needs an administrator-provided AI analysis access code. Do not paste a Nebius API key into the browser. The image comparison itself does not need a paid-model call. Access credentials, if needed for separate AI testing, must be supplied through the organizer's private testing channel, not this downloadable kit.

Images retain their original CC0 declaration; scripts and task-guide additions use the included MIT notice. See `IMAGE-LICENSE.txt` and `LICENSE-code.txt`. This folder is a local publication candidate until the owner approves its release.
